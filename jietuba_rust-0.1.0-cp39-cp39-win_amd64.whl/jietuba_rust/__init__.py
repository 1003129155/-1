from .jietuba_rust import *

__doc__ = jietuba_rust.__doc__
if hasattr(jietuba_rust, "__all__"):
    __all__ = jietuba_rust.__all__